Instructions:
1. Upload this folder to https://vercel.com or https://netlify.com
2. Or serve it using any static web server.
3. Tokens are sent manually after SOL is received at: Fg66DrzN1A7MpdhFbJwHJUXfhPSzCkjBFnCR2qnUzksg
